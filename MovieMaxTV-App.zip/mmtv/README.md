# Movie Max TV — Android app

Shows your live site https://livetv.moviemax.site inside a full-screen app with its own icon and splash screen.

## Build the APK
1. Install Node.js 18+ and Android Studio (it includes the Android SDK and Java 17).
2. Open this folder in VS Code, then in the terminal run:
   npm install
   npx cap sync android
3. Build:
   - Debug APK:  npm run build:apk  (Windows: cd android && gradlew.bat assembleDebug)
     Output: android/app/build/outputs/apk/debug/app-debug.apk
   - Or run `npm run open` and use Build > Build APK(s) in Android Studio.
   - For Play Store / release, use Build > Generate Signed Bundle/APK.

## Updates
- Design, channels, payments, everything you publish on the website reaches every phone instantly. You do not need a new APK.
- New APK (native changes): raise versionCode/versionName in android/app/build.gradle, build, upload the APK online,
  then update https://livetv.moviemax.site/app-version.json:
  {"versionCode": 2, "apkUrl": "https://.../MovieMaxTV.apk", "notes": "What's new", "force": false}
  Installed apps detect it on open, download it automatically and show Android's install screen.
  Always sign updates with the same key, or Android rejects them.

## Change icon / splash
Replace assets/icon-only.png, icon-foreground.png, splash.png and run `npm run icons`.
