package site.moviemax.tv;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Checks https://livetv.moviemax.site/app-version.json and installs newer APKs.
        new AppUpdater(this).checkForUpdate();
    }

    @Override
    public void onResume() {
        super.onResume();
        new AppUpdater(this).checkForUpdate();
    }
}
