package site.moviemax.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/**
 * Automatic APK updates.
 * Publish a new APK online and raise "versionCode" in
 * https://livetv.moviemax.site/app-version.json — every installed app
 * detects it on open, downloads it and asks Android to install it.
 * Screens, channels and design update instantly without any APK, because the app
 * shows the live website.
 */
public class AppUpdater {
    static final String VERSION_URL = "https://livetv.moviemax.site/app-version.json";
    private static boolean checking = false;
    private final Activity activity;

    AppUpdater(Activity a) { activity = a; }

    void checkForUpdate() {
        if (checking) return;
        checking = true;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(VERSION_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setUseCaches(false);
                if (c.getResponseCode() != 200) { checking = false; return; }
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                JSONObject j = new JSONObject(sb.toString());
                int latest = j.optInt("versionCode", 0);
                String apk = j.optString("apkUrl", "");
                String notes = j.optString("notes", "A new version of Movie Max TV is ready.");
                boolean force = j.optBoolean("force", false);
                PackageInfo pi = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
                int current = (int) (Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
                if (latest > current && apk.startsWith("http")) {
                    activity.runOnUiThread(() -> ask(apk, notes, force));
                } else checking = false;
            } catch (Exception e) { checking = false; }
        }).start();
    }

    private void ask(String apk, String notes, boolean force) {
        AlertDialog.Builder b = new AlertDialog.Builder(activity)
            .setTitle("Update available")
            .setMessage(notes)
            .setCancelable(!force)
            .setPositiveButton("UPDATE NOW", (d, w) -> download(apk));
        if (!force) b.setNegativeButton("LATER", (d, w) -> checking = false);
        b.show();
    }

    private void download(String apk) {
        try {
            File dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            File out = new File(dir, "MovieMaxTV-update.apk");
            if (out.exists()) out.delete();
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apk))
                .setTitle("Movie Max TV update")
                .setDescription("Downloading the latest version")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(out));
            long id = dm.enqueue(req);
            BroadcastReceiver done = new BroadcastReceiver() {
                @Override public void onReceive(Context ctx, Intent i) {
                    if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                    try { activity.unregisterReceiver(this); } catch (Exception ignored) {}
                    install(out);
                }
            };
            IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(done, f, Context.RECEIVER_EXPORTED);
            else activity.registerReceiver(done, f);
        } catch (Exception e) { checking = false; }
    }

    private void install(File apk) {
        checking = false;
        if (Build.VERSION.SDK_INT >= 26 && !activity.getPackageManager().canRequestPackageInstalls()) {
            activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:" + activity.getPackageName())));
        }
        Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(i);
    }
}
